close, clear, clc;

A = [1 2 3; 4 5 6; 7 8 9];
res = six_two(A);
disp(res);

A = [1];
res = six_two(A);
disp(res);